# AI SMP — Fabric 1.21.11 (NPC prototype)

This update adds the first actual in-world NPCs. It is an **early prototype**, not the full autonomous-player simulation originally described.

## Included
- `/smp start`
- Five-second countdown shown in the action bar
- Spawns 20 named, persistent vanilla villagers in a circle around the player
- Villagers use Minecraft's built-in villager AI (wandering, village behavior, and normal villager interactions)
- Sets the Overworld border to 20,000 blocks across, centered on the player who starts the SMP
- Seven-minute grace-period timer and player invulnerability
- Broadcasts `PVP IS ENABLED` after grace period
- `/smp stop`
- `/smp player_locating true|false` setting

## Not included yet
These villagers are not human-like player agents. They do not independently mine, craft, build bases, create trading halls, use player equipment, fight strategically, travel dimensions, chat autonomously, or hunt the player. The locating command currently stores a toggle only. The grace period currently protects real players; it does not make NPCs invulnerable. Bot death/respawn management is also not implemented.

## Build
Requirements: JDK 21, Gradle, Minecraft 1.21.11 Fabric development dependencies.

Run from this folder:
```bash
gradle build
```
The output JAR is in `build/libs/` (choose the normal JAR, not `-sources` or `-dev`).

## Mobile build
Upload the project contents to a GitHub repository. Open its Actions tab and run the included **Build Fabric mod** workflow. Download the workflow artifact named `ai-smp-mod`.

Back up your world before testing. This source has not been compiled or tested in-game in this environment; if the build reports an error, share the complete error log so the project can be corrected.
