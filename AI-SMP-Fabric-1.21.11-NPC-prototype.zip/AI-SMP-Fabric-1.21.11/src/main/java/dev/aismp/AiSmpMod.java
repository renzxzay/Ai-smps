package dev.aismp;

import com.mojang.brigadier.arguments.BoolArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class AiSmpMod implements ModInitializer {
    private static final int BOT_COUNT = 20;
    private static final int COUNTDOWN_TICKS = 5 * 20;
    private static final int GRACE_TICKS = 7 * 60 * 20;
    private static final String BOT_TAG = "aismp_bot";

    private static int ticksLeft = -1;
    private static boolean running = false;
    private static boolean playerLocating = false;
    private static boolean botsSpawned = false;

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(literal("smp")
                .then(literal("start").executes(context -> {
                    MinecraftServer server = context.getSource().getServer();
                    if (running) {
                        context.getSource().sendError(Text.literal("The AI SMP is already running."));
                        return 0;
                    }
                    ServerPlayerEntity starter = context.getSource().getPlayerOrThrow();
                    running = true;
                    botsSpawned = false;
                    ticksLeft = COUNTDOWN_TICKS + GRACE_TICKS;
                    starter.getServerWorld().getWorldBorder().setCenter(starter.getX(), starter.getZ());
                    starter.getServerWorld().getWorldBorder().setSize(20000.0);
                    server.getPlayerManager().broadcast(Text.literal("AI SMP: 20 NPCs are preparing to deploy!"), false);
                    return 1;
                }))
                .then(literal("stop").executes(context -> {
                    stopSmp(context.getSource().getServer());
                    context.getSource().sendFeedback(() -> Text.literal("AI SMP stopped."), true);
                    return 1;
                }))
                .then(literal("player_locating")
                    .then(argument("enabled", BoolArgumentType.bool()).executes(context -> {
                        playerLocating = BoolArgumentType.getBool(context, "enabled");
                        context.getSource().sendFeedback(
                            () -> Text.literal("Player locating setting: " + playerLocating
                                + " (tracking behavior is not implemented in this prototype)."), true);
                        return 1;
                    })))
            )
        );

        ServerTickEvents.END_SERVER_TICK.register(AiSmpMod::tick);
    }

    private static void tick(MinecraftServer server) {
        if (!running || ticksLeft < 0) return;
        ticksLeft--;

        if (ticksLeft > GRACE_TICKS && ticksLeft % 20 == 0) {
            int seconds = (ticksLeft - GRACE_TICKS) / 20;
            actionBar(server, "NPCs deploy in " + seconds + "...");
        }

        if (!botsSpawned && ticksLeft == GRACE_TICKS) {
            spawnBots(server);
            botsSpawned = true;
            server.getPlayerManager().broadcast(
                Text.literal("20 AI SMP NPCs have spawned. Grace period: 7 minutes."), false);
        }

        if (ticksLeft > 0 && ticksLeft <= GRACE_TICKS && ticksLeft % 20 == 0) {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                player.setInvulnerable(true);
            }
            int seconds = ticksLeft / 20;
            actionBar(server, "Grace period: " + (seconds / 60) + ":" + String.format("%02d", seconds % 60));
        }

        if (ticksLeft == 0) {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                player.setInvulnerable(false);
            }
            server.getPlayerManager().broadcast(Text.literal("PVP IS ENABLED"), false);
            actionBar(server, "Grace period ended!");
            ticksLeft = -1;
        }
    }

    private static void spawnBots(MinecraftServer server) {
        ServerPlayerEntity host = server.getPlayerManager().getPlayerList().stream().findFirst().orElse(null);
        if (host == null) return;
        ServerWorld world = host.getServerWorld();
        double centerX = host.getX();
        double centerZ = host.getZ();
        double radius = 5.0;

        for (int i = 0; i < BOT_COUNT; i++) {
            double angle = (Math.PI * 2.0 * i) / BOT_COUNT;
            double x = centerX + Math.cos(angle) * radius;
            double z = centerZ + Math.sin(angle) * radius;
            BlockPos ground = world.getTopPosition(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                BlockPos.ofFloored(x, host.getY(), z));

            VillagerEntity villager = net.minecraft.entity.EntityType.VILLAGER.create(world);
            if (villager == null) continue;
            villager.refreshPositionAndAngles(ground.getX() + 0.5, ground.getY(), ground.getZ() + 0.5,
                (float) (angle * 180.0 / Math.PI), 0.0f);
            villager.setCustomName(Text.literal("SMP Bot " + String.format("%02d", i + 1)));
            villager.setCustomNameVisible(true);
            villager.setPersistent();
            villager.addCommandTag(BOT_TAG);
            world.spawnEntity(villager);
        }
    }

    private static void actionBar(MinecraftServer server, String message) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            player.sendMessage(Text.literal(message), true);
        }
    }

    private static void stopSmp(MinecraftServer server) {
        running = false;
        ticksLeft = -1;
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            player.setInvulnerable(false);
        }
    }
}
